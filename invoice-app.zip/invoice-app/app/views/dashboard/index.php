<?php $pageTitle = __t('dashboard'); ?>
<?php require BASE_PATH . '/views/layout/header.php'; ?>

<div class="mb-6">
  <h1 class="text-xl font-bold text-slate-800"><?= __t('dashboard') ?></h1>
  <p class="text-slate-500 text-sm mt-0.5"><?= date('l, d F Y') ?></p>
</div>

<!-- Stats cards -->
<div class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
  <?php
  $cards = [
    ['label' => __t('total_invoices'), 'value' => $stats['total'],    'icon' => 'fa-file-invoice',   'color' => 'bg-blue-500'],
    ['label' => __t('paid'),           'value' => $stats['paid'],     'icon' => 'fa-circle-check',   'color' => 'bg-green-500'],
    ['label' => __t('unpaid'),         'value' => $stats['unpaid'],   'icon' => 'fa-clock',          'color' => 'bg-amber-500'],
    ['label' => __t('cancelled'),      'value' => $stats['cancelled'],'icon' => 'fa-circle-xmark',   'color' => 'bg-red-400'],
  ];
  foreach ($cards as $c):
  ?>
  <div class="bg-white rounded-xl p-5 shadow-sm border border-slate-100 flex items-center gap-4">
    <div class="<?= $c['color'] ?> text-white rounded-xl w-11 h-11 flex items-center justify-center flex-shrink-0">
      <i class="fa <?= $c['icon'] ?> text-lg"></i>
    </div>
    <div>
      <div class="text-2xl font-bold text-slate-800"><?= $c['value'] ?></div>
      <div class="text-slate-500 text-xs"><?= $c['label'] ?></div>
    </div>
  </div>
  <?php endforeach; ?>
</div>

<!-- Revenue card -->
<div class="bg-gradient-to-r from-slate-900 to-slate-700 rounded-xl p-6 mb-6 text-white shadow">
  <div class="text-slate-400 text-sm"><?= __t('total_revenue') ?></div>
  <div class="text-3xl font-bold mt-1"><?= formatCurrency((float)$stats['revenue']) ?></div>
  <div class="text-slate-400 text-xs mt-1"><?= __t('status_paid') ?></div>
</div>

<!-- Recent invoices -->
<div class="bg-white rounded-xl shadow-sm border border-slate-100">
  <div class="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
    <h2 class="font-semibold text-slate-700"><?= __t('recent_invoices') ?></h2>
    <a href="/invoices/create" class="bg-slate-900 hover:bg-slate-700 text-white text-xs px-3 py-1.5 rounded-lg transition-colors">
      + <?= __t('create_invoice') ?>
    </a>
  </div>
  <div class="overflow-x-auto">
    <table class="w-full text-sm">
      <thead class="bg-slate-50 text-xs text-slate-500 uppercase tracking-wide">
        <tr>
          <th class="text-left px-5 py-3"><?= __t('invoice_number') ?></th>
          <th class="text-left px-4 py-3"><?= __t('clients') ?></th>
          <th class="text-left px-4 py-3"><?= __t('invoice_type') ?></th>
          <th class="text-right px-4 py-3"><?= __t('total') ?></th>
          <th class="text-left px-4 py-3"><?= __t('status') ?></th>
          <th class="text-left px-4 py-3"><?= __t('invoice_date') ?></th>
        </tr>
      </thead>
      <tbody class="divide-y divide-slate-50">
        <?php foreach ($recent as $inv): ?>
        <?php
          $statusClass = match($inv['status']) {
            'paid'      => 'bg-green-100 text-green-700',
            'cancelled' => 'bg-red-100 text-red-600',
            default     => 'bg-amber-100 text-amber-700',
          };
          $typeLabel = match($inv['type']) {
            'barang'     => __t('type_barang'),
            'jasa'       => __t('type_jasa'),
            'penginapan' => __t('type_penginapan'),
            default      => ucfirst($inv['type']),
          };
        ?>
        <tr class="hover:bg-slate-50 transition-colors">
          <td class="px-5 py-3 font-mono text-xs text-blue-700">
            <a href="/invoices/edit?id=<?= $inv['id'] ?>" class="hover:underline"><?= e($inv['invoice_number']) ?></a>
          </td>
          <td class="px-4 py-3 text-slate-600"><?= e($inv['client_name'] ?: '—') ?></td>
          <td class="px-4 py-3 text-slate-500 text-xs"><?= e($typeLabel) ?></td>
          <td class="px-4 py-3 text-right font-medium text-slate-800"><?= formatCurrency($inv['total'], $inv['currency']) ?></td>
          <td class="px-4 py-3">
            <span class="<?= $statusClass ?> px-2 py-0.5 rounded-full text-xs font-medium">
              <?= __t('status_' . $inv['status']) ?>
            </span>
          </td>
          <td class="px-4 py-3 text-slate-500 text-xs"><?= e($inv['issue_date']) ?></td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($recent)): ?>
        <tr><td colspan="6" class="px-5 py-8 text-center text-slate-400"><?= __t('not_found') ?></td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require BASE_PATH . '/views/layout/footer.php'; ?>
