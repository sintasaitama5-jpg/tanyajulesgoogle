<!DOCTYPE html>
<html lang="<?= \App\Lang::current() ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($pageTitle ?? 'Invoice') ?> — <?= e(setting('app_name','InvoiceApp')) ?></title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
  [x-cloak]{display:none}
  .sidebar-link{@apply flex items-center gap-3 px-4 py-2.5 rounded-lg text-slate-300 hover:bg-white/10 hover:text-white transition-all text-sm font-medium;}
  .sidebar-link.active{@apply bg-white/20 text-white;}
</style>
</head>
<body class="bg-slate-100 min-h-screen">
<?php $user = \App\Auth::user(); ?>
<div class="flex min-h-screen">

  <!-- Sidebar -->
  <aside class="w-56 bg-slate-900 flex flex-col min-h-screen fixed left-0 top-0 z-30">
    <div class="px-5 py-5 border-b border-white/10">
      <div class="text-white font-bold text-lg"><?= e(setting('app_name','InvoiceApp')) ?></div>
      <div class="text-slate-400 text-xs mt-0.5"><?= e($user['name'] ?? '') ?> · <?= ucfirst($user['role'] ?? '') ?></div>
    </div>

    <nav class="flex-1 px-3 py-4 space-y-0.5">
      <?php $cur = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH); ?>
      <a href="/" class="sidebar-link <?= $cur === '/' ? 'active' : '' ?>">
        <i class="fa fa-gauge-high w-4"></i> <?= __t('dashboard') ?>
      </a>
      <a href="/invoices" class="sidebar-link <?= str_starts_with($cur, '/invoices') ? 'active' : '' ?>">
        <i class="fa fa-file-invoice w-4"></i> <?= __t('invoices') ?>
      </a>
      <a href="/clients" class="sidebar-link <?= str_starts_with($cur, '/clients') ? 'active' : '' ?>">
        <i class="fa fa-users w-4"></i> <?= __t('clients') ?>
      </a>
      <a href="/companies" class="sidebar-link <?= str_starts_with($cur, '/companies') ? 'active' : '' ?>">
        <i class="fa fa-building w-4"></i> <?= __t('companies') ?>
      </a>
      <?php if (\App\Auth::isAdmin()): ?>
      <a href="/users" class="sidebar-link <?= str_starts_with($cur, '/users') ? 'active' : '' ?>">
        <i class="fa fa-user-shield w-4"></i> <?= __t('users') ?>
      </a>
      <a href="/settings" class="sidebar-link <?= str_starts_with($cur, '/settings') ? 'active' : '' ?>">
        <i class="fa fa-gear w-4"></i> <?= __t('settings') ?>
      </a>
      <?php endif; ?>
    </nav>

    <div class="px-3 py-4 border-t border-white/10 space-y-1">
      <!-- Language toggle -->
      <a href="/lang?lang=<?= \App\Lang::other() ?>"
         class="flex items-center gap-2 px-4 py-2 text-xs text-slate-400 hover:text-white rounded-lg hover:bg-white/10 transition-all">
        <i class="fa fa-language"></i>
        <?= \App\Lang::current() === 'id' ? 'Switch to English' : 'Ganti ke Indonesia' ?>
      </a>
      <a href="/logout" class="flex items-center gap-2 px-4 py-2 text-xs text-slate-400 hover:text-red-400 rounded-lg hover:bg-white/10 transition-all">
        <i class="fa fa-right-from-bracket"></i> <?= __t('logout') ?>
      </a>
    </div>
  </aside>

  <!-- Main content -->
  <main class="flex-1 ml-56 min-h-screen flex flex-col">
    <div class="flex-1 p-6 max-w-7xl w-full">

      <!-- Flash messages -->
      <?php $success = flash('success'); $error = flash('error'); ?>
      <?php if ($success): ?>
      <div class="mb-4 px-4 py-3 bg-green-50 border border-green-200 text-green-800 rounded-lg text-sm flex items-center gap-2">
        <i class="fa fa-check-circle"></i> <?= e($success) ?>
      </div>
      <?php endif; ?>
      <?php if ($error): ?>
      <div class="mb-4 px-4 py-3 bg-red-50 border border-red-200 text-red-800 rounded-lg text-sm flex items-center gap-2">
        <i class="fa fa-circle-exclamation"></i> <?= e($error) ?>
      </div>
      <?php endif; ?>
